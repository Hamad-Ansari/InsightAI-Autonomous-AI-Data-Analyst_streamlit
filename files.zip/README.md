# InsightAI — Autonomous AI Data Analyst (single-file edition)

Upload a dataset → get automatic cleaning, EDA, the four analytical
dimensions (Composition / Distribution / Comparison / Relationship),
sentiment analysis, time-series analysis, anomaly detection, an
interactive dashboard, AI-generated business insights (local Ollama +
lightweight RAG), and a downloadable HTML/CSV/JSON report.

Everything lives in **`app.py`** — one file, fully runnable.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Open the URL Streamlit prints (usually http://localhost:8501).

A sample dataset is included at `sample_data/sales_sample.csv` — upload
it first to see everything in action.

## Optional: AI insights via Ollama

```bash
# install from https://ollama.com, then:
ollama pull llama3.1:8b
ollama serve
```

Without Ollama running, every deterministic calculation (EDA, stats,
charts, cleaning, sentiment, time series, anomalies) still works fully.
Only the "AI Insights" page needs it — it turns already-computed numbers
into a written business summary and never lets the model invent numbers.

## Design principle

Python/Pandas/Scikit-learn/Statsmodels do **all** the math. Ollama only
receives the finished JSON of computed results and explains it in
plain business language — it is never asked to calculate anything
itself, so numbers can't be hallucinated.

## Optional semantic RAG

By default the RAG knowledge base (EDA methodology, stats interpretation,
cleaning guidelines, etc.) is retrieved with a keyword-overlap fallback
so the app runs with zero extra setup. Installing `sentence-transformers`
(already in `requirements.txt`) upgrades retrieval to real embedding
similarity automatically — no code changes needed.

## What's NOT included (see limitations)

This single-file build keeps the full 30+ file production architecture
(FastAPI, LangGraph agent, Docker, full test suite, PDF export, per-module
folder structure) out of scope on purpose, since you asked for one file.
If you want the fully modular, multi-file production version with tests,
Docker, and a PDF exporter, say the word and I'll build that out properly
instead of cramming it into a single script.
