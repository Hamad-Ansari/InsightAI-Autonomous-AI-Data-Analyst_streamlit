"""
================================================================================
 InsightAI — Autonomous AI Data Analyst  (single-file edition)
================================================================================
Upload almost any tabular dataset and get automatic data understanding,
cleaning, EDA, statistical analysis, sentiment analysis, time-series
analysis, visualization, an interactive dashboard, AI-generated business
insights (via a local Ollama model + a lightweight RAG layer), and a
downloadable final report.

Run:
    streamlit run app.py

Optional (for AI insights):
    Install Ollama (https://ollama.com) and pull a model, e.g.:
        ollama pull llama3.1:8b
    The app works fully without Ollama — every calculation is done in
    Python/Pandas/Scikit-learn/Statsmodels. Ollama only turns the
    already-computed numbers into readable business language.
================================================================================
"""

from __future__ import annotations

import io
import json
import os
import re
import warnings
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import streamlit as st
from scipy import stats as scistats

warnings.filterwarnings("ignore")

# Optional heavy deps — degrade gracefully if not installed.
try:
    from sklearn.ensemble import IsolationForest
    SKLEARN_OK = True
except Exception:
    SKLEARN_OK = False

try:
    from statsmodels.tsa.seasonal import seasonal_decompose
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    STATSMODELS_OK = True
except Exception:
    STATSMODELS_OK = False

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    VADER_OK = True
except Exception:
    VADER_OK = False

try:
    from sentence_transformers import SentenceTransformer
    SBERT_OK = True
except Exception:
    SBERT_OK = False

try:
    import chromadb
    CHROMA_OK = True
except Exception:
    CHROMA_OK = False


# ==============================================================================
# 0. CONFIG
# ==============================================================================

@dataclass
class Settings:
    ollama_url: str = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
    ollama_model: str = os.environ.get("OLLAMA_MODEL", "llama3.1:8b")
    embedding_model: str = os.environ.get("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    temperature: float = 0.3
    max_tokens: int = 900
    rag_top_k: int = 3
    max_upload_mb: int = int(os.environ.get("MAX_UPLOAD_SIZE_MB", 200))


SETTINGS = Settings()

APP_TITLE = "InsightAI"
APP_SUBTITLE = "Autonomous AI Data Analyst"

st.set_page_config(page_title=APP_TITLE, layout="wide", page_icon="📊")


# ==============================================================================
# 1. DATA INGESTION
# ==============================================================================

def read_uploaded_file(uploaded_file) -> pd.DataFrame:
    """Robustly load CSV / Excel / TSV / Parquet with encoding fallback."""
    name = uploaded_file.name.lower()
    raw = uploaded_file.read()
    if len(raw) == 0:
        raise ValueError("The uploaded file is empty.")
    if len(raw) > SETTINGS.max_upload_mb * 1024 * 1024:
        raise ValueError(f"File exceeds the {SETTINGS.max_upload_mb} MB limit.")

    buf = io.BytesIO(raw)

    if name.endswith(".parquet"):
        return pd.read_parquet(buf)

    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(buf)

    # CSV / TSV — try a few encodings + separators
    sep = "\t" if name.endswith(".tsv") else None
    last_err = None
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            buf.seek(0)
            if sep:
                return pd.read_csv(buf, sep=sep, encoding=enc)
            return pd.read_csv(buf, sep=None, engine="python", encoding=enc)
        except Exception as e:  # noqa: BLE001
            last_err = e
            continue
    raise ValueError(f"Could not parse file with any supported encoding ({last_err}).")


# ==============================================================================
# 2. SCHEMA / DATA-TYPE DETECTION
# ==============================================================================

ID_PATTERN = re.compile(r"(^id$|_id$|^id_|uuid|guid)", re.I)
CURRENCY_PATTERN = re.compile(r"(price|amount|revenue|cost|salary|fee|income|value|total|payment)", re.I)
PERCENT_PATTERN = re.compile(r"(pct|percent|rate|ratio|%)", re.I)
BOOL_VALUES = {"true", "false", "yes", "no", "y", "n", "0", "1", "t", "f"}


def detect_schema(df: pd.DataFrame) -> dict[str, str]:
    """Classify every column into NUMERIC / CATEGORICAL / DATETIME / TEXT /
    BOOLEAN / ID / CURRENCY / PERCENTAGE / UNKNOWN."""
    schema: dict[str, str] = {}
    n = max(len(df), 1)

    for col in df.columns:
        s = df[col]
        nunique = s.nunique(dropna=True)
        non_null = s.dropna()

        if ID_PATTERN.search(str(col)) and (nunique / n > 0.9 or nunique == n):
            schema[col] = "ID"
            continue

        if pd.api.types.is_bool_dtype(s):
            schema[col] = "BOOLEAN"
            continue

        if pd.api.types.is_datetime64_any_dtype(s):
            schema[col] = "DATETIME"
            continue

        if pd.api.types.is_numeric_dtype(s):
            if PERCENT_PATTERN.search(str(col)):
                schema[col] = "PERCENTAGE"
            elif CURRENCY_PATTERN.search(str(col)):
                schema[col] = "CURRENCY"
            else:
                schema[col] = "NUMERIC"
            continue

        # try datetime parse
        is_stringy = pd.api.types.is_object_dtype(s) or pd.api.types.is_string_dtype(s)
        if is_stringy and len(non_null) > 0:
            sample = non_null.astype(str).head(30)
            try:
                parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
                if parsed.notna().mean() > 0.8:
                    schema[col] = "DATETIME"
                    continue
            except Exception:
                pass

            lowered = set(sample.str.lower().str.strip().unique())
            if lowered and lowered.issubset(BOOL_VALUES):
                schema[col] = "BOOLEAN"
                continue

            # numeric-looking strings
            cleaned = sample.str.replace(r"[,$%\s]", "", regex=True)
            numeric_like = pd.to_numeric(cleaned, errors="coerce")
            if numeric_like.notna().mean() > 0.85:
                schema[col] = "CURRENCY" if CURRENCY_PATTERN.search(str(col)) else "NUMERIC"
                continue

            avg_len = non_null.astype(str).str.len().mean()
            avg_words = non_null.astype(str).str.split().str.len().mean()
            if avg_len > 40 or avg_words > 6:
                schema[col] = "TEXT"
            elif nunique / n < 0.5 or nunique < 50:
                schema[col] = "CATEGORICAL"
            else:
                schema[col] = "TEXT"
            continue

        schema[col] = "UNKNOWN"

    return schema


def columns_by_type(schema: dict[str, str], *types: str) -> list[str]:
    return [c for c, t in schema.items() if t in types]


# ==============================================================================
# 3. DATA CLEANING
# ==============================================================================

@dataclass
class CleaningLogEntry:
    column: str
    operation: str
    rows_affected: int
    reason: str


def clean_dataset(df: pd.DataFrame, schema: dict[str, str]) -> tuple[pd.DataFrame, list[CleaningLogEntry]]:
    """Perform only SAFE automatic cleaning. Never silently destroys data —
    every change is logged. The original dataframe is never mutated."""
    cleaned = df.copy()
    log: list[CleaningLogEntry] = []

    # 1. Exact duplicate rows
    dup_mask = cleaned.duplicated()
    if dup_mask.sum() > 0:
        log.append(CleaningLogEntry("<all>", "remove_exact_duplicates", int(dup_mask.sum()),
                                     "Exact duplicate rows add no information and bias aggregates."))
        cleaned = cleaned[~dup_mask]

    # 2. Empty / fully-constant columns
    for col in list(cleaned.columns):
        if cleaned[col].isna().all():
            log.append(CleaningLogEntry(col, "flag_empty_column", len(cleaned),
                                         "Column is 100% missing; kept but excluded from numeric analysis."))
        elif cleaned[col].nunique(dropna=True) == 1:
            log.append(CleaningLogEntry(col, "flag_constant_column", len(cleaned),
                                         "Column has a single constant value; low analytical value."))

    for col, dtype in schema.items():
        if col not in cleaned.columns:
            continue
        s = cleaned[col]

        # 3. Trim whitespace on strings
        is_stringy = pd.api.types.is_object_dtype(s) or pd.api.types.is_string_dtype(s)
        if is_stringy:
            trimmed = s.astype(str).str.strip()
            changed = (trimmed != s.astype(str)).sum()
            if changed > 0:
                cleaned[col] = trimmed.where(s.notna(), s)
                log.append(CleaningLogEntry(col, "trim_whitespace", int(changed),
                                             "Leading/trailing whitespace can create false categories."))

        # 4. Normalize categorical capitalization
        if dtype == "CATEGORICAL" and is_stringy:
            normalized = cleaned[col].astype(str).str.strip().str.lower()
            before = cleaned[col].nunique(dropna=True)
            after = normalized.nunique(dropna=True)
            if after < before:
                cleaned[col] = normalized.where(cleaned[col].notna(), cleaned[col])
                log.append(CleaningLogEntry(col, "normalize_capitalization", len(cleaned),
                                             f"Reduced {before} inconsistent categories to {after}."))

        # 5. Convert numeric-looking strings to numeric
        if dtype in ("NUMERIC", "CURRENCY", "PERCENTAGE") and not pd.api.types.is_numeric_dtype(cleaned[col]):
            cleaned_series = cleaned[col].astype(str).str.replace(r"[,$%\s]", "", regex=True)
            converted = pd.to_numeric(cleaned_series, errors="coerce")
            n_converted = converted.notna().sum() - cleaned[col].apply(lambda x: isinstance(x, (int, float))).sum()
            cleaned[col] = converted
            log.append(CleaningLogEntry(col, "convert_to_numeric", int(converted.notna().sum()),
                                         "Numeric-looking text converted to true numeric type."))

        # 6. Convert recognizable dates
        if dtype == "DATETIME" and not pd.api.types.is_datetime64_any_dtype(cleaned[col]):
            converted = pd.to_datetime(cleaned[col], errors="coerce", format="mixed")
            log.append(CleaningLogEntry(col, "convert_to_datetime", int(converted.notna().sum()),
                                         "Recognized date strings parsed into true datetime type."))
            cleaned[col] = converted

    # 7. Missing-value imputation (numeric -> median, categorical -> mode)
    for col, dtype in schema.items():
        if col not in cleaned.columns:
            continue
        n_missing = cleaned[col].isna().sum()
        if n_missing == 0:
            continue
        if dtype in ("NUMERIC", "CURRENCY", "PERCENTAGE") and pd.api.types.is_numeric_dtype(cleaned[col]):
            median_val = cleaned[col].median()
            cleaned[col] = cleaned[col].fillna(median_val)
            log.append(CleaningLogEntry(col, "impute_median", int(n_missing),
                                         f"Filled missing numeric values with median ({median_val:.2f})."))
        elif dtype == "CATEGORICAL":
            mode_series = cleaned[col].mode(dropna=True)
            if not mode_series.empty:
                mode_val = mode_series.iloc[0]
                cleaned[col] = cleaned[col].fillna(mode_val)
                log.append(CleaningLogEntry(col, "impute_mode", int(n_missing),
                                             f"Filled missing categorical values with mode ('{mode_val}')."))
        # DATETIME / TEXT / ID / UNKNOWN: never blindly imputed.

    return cleaned, log


# ==============================================================================
# 4. OUTLIER DETECTION
# ==============================================================================

def detect_outliers_iqr(series: pd.Series) -> pd.Series:
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    extreme_lower, extreme_upper = q1 - 3 * iqr, q3 + 3 * iqr

    def classify(v):
        if v < extreme_lower or v > extreme_upper:
            return "Extreme Outlier"
        if v < lower or v > upper:
            return "Potential Outlier"
        return "Normal"

    return series.apply(classify)


def outlier_summary(df: pd.DataFrame, numeric_cols: list[str]) -> pd.DataFrame:
    rows = []
    for col in numeric_cols:
        s = df[col].dropna()
        if s.empty:
            continue
        classes = detect_outliers_iqr(s)
        counts = classes.value_counts()
        rows.append({
            "column": col,
            "normal": int(counts.get("Normal", 0)),
            "potential_outliers": int(counts.get("Potential Outlier", 0)),
            "extreme_outliers": int(counts.get("Extreme Outlier", 0)),
            "outlier_pct": round(100 * (len(s) - counts.get("Normal", 0)) / len(s), 2),
        })
    return pd.DataFrame(rows)


# ==============================================================================
# 5. DATA QUALITY SCORE
# ==============================================================================

def data_quality_score(df: pd.DataFrame) -> dict[str, Any]:
    n_rows = len(df) or 1
    missing_rate = df.isna().sum().sum() / (n_rows * max(len(df.columns), 1))
    dup_rate = df.duplicated().sum() / n_rows
    constant_cols = sum(1 for c in df.columns if df[c].nunique(dropna=True) <= 1)
    constant_rate = constant_cols / max(len(df.columns), 1)

    score = 100 * (1 - 0.5 * missing_rate - 0.3 * dup_rate - 0.2 * constant_rate)
    score = max(0, min(100, round(score, 1)))
    return {
        "score": score,
        "missing_rate_pct": round(missing_rate * 100, 2),
        "duplicate_rate_pct": round(dup_rate * 100, 2),
        "constant_columns": constant_cols,
    }


# ==============================================================================
# 6. UNIVARIATE / FOUR-DIMENSION ANALYSIS
# ==============================================================================

def univariate_numeric(df: pd.DataFrame, col: str) -> dict[str, Any]:
    s = df[col].dropna()
    if s.empty:
        return {}
    return {
        "mean": s.mean(), "median": s.median(),
        "mode": s.mode().iloc[0] if not s.mode().empty else np.nan,
        "std": s.std(), "variance": s.var(), "min": s.min(), "max": s.max(),
        "q1": s.quantile(0.25), "q3": s.quantile(0.75),
        "skewness": scistats.skew(s), "kurtosis": scistats.kurtosis(s),
    }


def univariate_categorical(df: pd.DataFrame, col: str) -> pd.DataFrame:
    counts = df[col].value_counts(dropna=True).head(15)
    pct = (counts / counts.sum() * 100).round(2)
    return pd.DataFrame({"category": counts.index, "count": counts.values, "pct": pct.values})


def composition_analysis(df: pd.DataFrame, cat_col: str, num_col: str | None) -> pd.DataFrame:
    if num_col:
        grouped = df.groupby(cat_col)[num_col].sum().sort_values(ascending=False).head(12)
    else:
        grouped = df[cat_col].value_counts().head(12)
    return grouped.reset_index().set_axis(["category", "value"], axis=1)


def comparison_analysis(df: pd.DataFrame, cat_col: str, num_col: str) -> pd.DataFrame:
    grouped = df.groupby(cat_col)[num_col].agg(["mean", "sum", "count"]).reset_index()
    return grouped.sort_values("sum", ascending=False).head(15)


def relationship_analysis(df: pd.DataFrame, numeric_cols: list[str]) -> pd.DataFrame:
    if len(numeric_cols) < 2:
        return pd.DataFrame()
    return df[numeric_cols].corr(method="pearson")


def strongest_relationships(corr: pd.DataFrame, top_n: int = 5) -> list[tuple[str, str, float]]:
    pairs = []
    cols = corr.columns
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            val = corr.iloc[i, j]
            if pd.notna(val):
                pairs.append((cols[i], cols[j], val))
    pairs.sort(key=lambda x: abs(x[2]), reverse=True)
    return pairs[:top_n]


# ==============================================================================
# 7. MISSING DATA ANALYSIS
# ==============================================================================

def missing_data_report(df: pd.DataFrame) -> pd.DataFrame:
    miss = df.isna().sum()
    pct = (miss / max(len(df), 1) * 100).round(2)
    out = pd.DataFrame({"column": miss.index, "missing_count": miss.values, "missing_pct": pct.values})
    return out[out["missing_count"] > 0].sort_values("missing_pct", ascending=False)


# ==============================================================================
# 8. TIME-SERIES ANALYSIS
# ==============================================================================

def time_series_analysis(df: pd.DataFrame, date_col: str, value_col: str) -> dict[str, Any]:
    ts = df[[date_col, value_col]].dropna().copy()
    ts[date_col] = pd.to_datetime(ts[date_col], errors="coerce")
    ts = ts.dropna().sort_values(date_col)
    if len(ts) < 5:
        return {"error": "Not enough data points for time-series analysis (need at least 5)."}

    ts = ts.set_index(date_col)
    daily = ts[value_col].resample("D").sum()
    monthly = ts[value_col].resample("ME").sum()

    result: dict[str, Any] = {
        "daily": daily, "monthly": monthly,
        "rolling_7": daily.rolling(7, min_periods=1).mean(),
        "total_periods": len(monthly),
    }

    if len(monthly) >= 2:
        first, last = monthly.iloc[0], monthly.iloc[-1]
        growth = ((last - first) / first * 100) if first != 0 else np.nan
        result["overall_growth_pct"] = round(growth, 2) if pd.notna(growth) else None
        result["period_over_period_pct"] = monthly.pct_change().mul(100).round(2)

    if STATSMODELS_OK and len(monthly) >= 8:
        try:
            decomposition = seasonal_decompose(monthly.fillna(0), period=min(12, len(monthly) // 2), model="additive")
            result["decomposition"] = decomposition
        except Exception:
            pass
        try:
            model = ExponentialSmoothing(monthly.fillna(0), trend="add", seasonal=None).fit()
            forecast = model.forecast(3)
            result["forecast"] = forecast
        except Exception:
            pass

    return result


# ==============================================================================
# 9. SENTIMENT ANALYSIS
# ==============================================================================

@st.cache_resource(show_spinner=False)
def get_sentiment_analyzer():
    if VADER_OK:
        return SentimentIntensityAnalyzer()
    return None


def sentiment_analysis(df: pd.DataFrame, text_col: str) -> pd.DataFrame | None:
    analyzer = get_sentiment_analyzer()
    if analyzer is None:
        return None
    texts = df[text_col].dropna().astype(str)
    scores = texts.apply(lambda t: analyzer.polarity_scores(t)["compound"])

    def label(v):
        if v >= 0.05:
            return "Positive"
        if v <= -0.05:
            return "Negative"
        return "Neutral"

    out = pd.DataFrame({"text": texts.values, "compound": scores.values})
    out["sentiment"] = out["compound"].apply(label)
    return out


def frequent_words(texts: pd.Series, sentiment_labels: pd.Series, target: str, top_n: int = 10) -> list[tuple[str, int]]:
    stop = {"the", "a", "an", "is", "it", "and", "to", "of", "in", "for", "was", "this", "that",
            "i", "we", "on", "with", "very", "but", "so", "at", "as", "are", "be", "not", "my"}
    subset = texts[sentiment_labels == target].str.lower()
    words: dict[str, int] = {}
    for t in subset:
        for w in re.findall(r"[a-zA-Z']+", t):
            if w not in stop and len(w) > 2:
                words[w] = words.get(w, 0) + 1
    return sorted(words.items(), key=lambda x: x[1], reverse=True)[:top_n]


# ==============================================================================
# 10. ANOMALY DETECTION
# ==============================================================================

def anomaly_detection(df: pd.DataFrame, numeric_cols: list[str]) -> pd.DataFrame:
    if not numeric_cols:
        return pd.DataFrame()
    work = df[numeric_cols].dropna()
    if work.empty:
        return pd.DataFrame()

    result = work.copy()
    if SKLEARN_OK and len(work) >= 10:
        try:
            iso = IsolationForest(contamination=0.05, random_state=42)
            preds = iso.fit_predict(work)
            result["anomaly"] = np.where(preds == -1, "Anomaly", "Normal")
        except Exception:
            result["anomaly"] = "Normal"
    else:
        z = np.abs(scistats.zscore(work, nan_policy="omit"))
        result["anomaly"] = np.where((z > 3).any(axis=1), "Anomaly", "Normal")

    return result[result["anomaly"] == "Anomaly"]


# ==============================================================================
# 11. AUTOMATIC CHART SELECTION
# ==============================================================================

def auto_chart(df: pd.DataFrame, x: str, y: str | None, schema: dict[str, str]):
    x_type = schema.get(x, "UNKNOWN")
    y_type = schema.get(y, "UNKNOWN") if y else None

    if y is None:
        if x_type in ("NUMERIC", "CURRENCY", "PERCENTAGE"):
            return px.histogram(df, x=x, title=f"Distribution of {x}")
        return px.bar(df[x].value_counts().head(15).reset_index(), x=x, y="count",
                      title=f"Frequency of {x}") if hasattr(df[x].value_counts().head(15).reset_index(), "columns") else None

    if x_type == "DATETIME" and y_type in ("NUMERIC", "CURRENCY", "PERCENTAGE"):
        return px.line(df.sort_values(x), x=x, y=y, title=f"{y} over time")
    if x_type == "CATEGORICAL" and y_type in ("NUMERIC", "CURRENCY", "PERCENTAGE"):
        return px.bar(df.groupby(x)[y].sum().reset_index().sort_values(y, ascending=False).head(15),
                      x=x, y=y, title=f"{y} by {x}")
    if x_type in ("NUMERIC", "CURRENCY", "PERCENTAGE") and y_type in ("NUMERIC", "CURRENCY", "PERCENTAGE"):
        return px.scatter(df, x=x, y=y, trendline="ols" if SKLEARN_OK else None, title=f"{x} vs {y}")
    return px.scatter(df, x=x, y=y, title=f"{x} vs {y}")


# ==============================================================================
# 12. LIGHTWEIGHT RAG LAYER
# ==============================================================================

KNOWLEDGE_BASE = [
    ("eda_methodology", "Exploratory Data Analysis (EDA) is the process of summarizing a dataset's main "
     "characteristics using statistics and visualizations before formal modeling. It covers univariate, "
     "bivariate, and multivariate exploration to surface structure, quality problems, and relationships."),
    ("data_cleaning", "Data cleaning guidelines: remove exact duplicates, standardize categorical casing, "
     "convert numeric-looking strings to numbers, parse dates explicitly, and impute missing values using "
     "the median for numeric fields and the mode for categorical fields. Never impute datetime columns blindly."),
    ("distribution", "Distribution analysis describes how values are spread using mean, median, standard "
     "deviation, skewness and kurtosis. Positive skew means a long right tail (few very large values); "
     "high kurtosis means more extreme outliers than a normal distribution."),
    ("correlation", "Pearson correlation measures linear association between two numeric variables from -1 "
     "to 1. Correlation does not imply causation. Spearman correlation captures monotonic (not necessarily "
     "linear) relationships and is more robust to outliers."),
    ("timeseries", "Time-series analysis examines trend, seasonality, and noise over time. Seasonal "
     "decomposition splits a series into trend, seasonal, and residual components. Forecasts should always "
     "be presented with the caveat that they are estimates based on historical patterns, not guarantees."),
    ("sentiment", "Sentiment analysis classifies text as positive, neutral, or negative based on word "
     "polarity. Compound scores near 0 are neutral; scores above 0.05 are positive; scores below -0.05 are "
     "negative. Aggregate sentiment trends over time or by category reveal customer-experience shifts."),
    ("kpi", "Common business KPIs include revenue growth rate, customer churn rate, average order value, "
     "conversion rate, and customer lifetime value. KPIs should always be paired with a time window and a "
     "comparison baseline (previous period, target, or benchmark)."),
    ("outliers", "Outliers are values that deviate substantially from the rest of the data. The IQR method "
     "flags values beyond 1.5x (potential) or 3x (extreme) the interquartile range from Q1/Q3. Outliers "
     "should be investigated, not automatically deleted, since they may be genuine and important."),
    ("data_quality", "A data quality score summarizes completeness (missing rate), uniqueness (duplicate "
     "rate), and validity (constant or malformed columns) into a single 0-100 metric to prioritize cleaning "
     "effort."),
    ("visualization", "Chart choice should follow data types: histograms/box plots for single numeric "
     "distributions, bar charts for categorical comparisons, line charts for trends over time, scatter plots "
     "for numeric relationships, and heatmaps for correlation matrices."),
]


@st.cache_resource(show_spinner=False)
def get_embedder():
    if SBERT_OK:
        try:
            return SentenceTransformer(SETTINGS.embedding_model)
        except Exception:
            return None
    return None


def rag_retrieve(query: str, top_k: int = SETTINGS.rag_top_k) -> list[str]:
    """Retrieve relevant methodology snippets. Uses sentence-transformer
    embeddings when available, otherwise falls back to keyword overlap."""
    embedder = get_embedder()
    docs = [d[1] for d in KNOWLEDGE_BASE]

    if embedder is not None:
        try:
            doc_emb = embedder.encode(docs)
            q_emb = embedder.encode([query])[0]
            sims = doc_emb @ q_emb / (np.linalg.norm(doc_emb, axis=1) * np.linalg.norm(q_emb) + 1e-9)
            top_idx = np.argsort(sims)[::-1][:top_k]
            return [docs[i] for i in top_idx]
        except Exception:
            pass

    # Keyword-overlap fallback (no external dependency required)
    q_words = set(re.findall(r"[a-z']+", query.lower()))
    scored = []
    for _, text in KNOWLEDGE_BASE:
        d_words = set(re.findall(r"[a-z']+", text.lower()))
        overlap = len(q_words & d_words)
        scored.append((overlap, text))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [t for _, t in scored[:top_k]]


# ==============================================================================
# 13. OLLAMA CLIENT
# ==============================================================================

def ollama_is_running(base_url: str) -> bool:
    try:
        r = requests.get(f"{base_url}/api/tags", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


def ollama_generate(prompt: str, base_url: str, model: str, temperature: float, max_tokens: int) -> str:
    try:
        r = requests.post(
            f"{base_url}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": temperature, "num_predict": max_tokens},
            },
            timeout=120,
        )
        r.raise_for_status()
        return r.json().get("response", "").strip()
    except Exception as e:  # noqa: BLE001
        return f"⚠️ Could not reach Ollama at {base_url} ({e}). Showing computed statistics only."


def build_insight_prompt(structured_results: dict[str, Any], rag_context: list[str]) -> str:
    context_block = "\n".join(f"- {c}" for c in rag_context)
    return f"""You are a senior data analyst writing for a business audience.
Use ONLY the numbers given below — never invent or estimate a number yourself.

METHODOLOGY CONTEXT:
{context_block}

COMPUTED ANALYTICAL RESULTS (JSON):
{json.dumps(structured_results, indent=2, default=str)}

Write a structured business analysis with these exact sections:
## Executive Summary
## Top 5 Findings
## Data Quality
## Trends
## Risks
## Opportunities
## Recommendations
## Further Questions

Keep it concise, business-friendly, and grounded strictly in the numbers above.
"""


# ==============================================================================
# 14. REPORT GENERATION
# ==============================================================================

def build_html_report(meta: dict, quality: dict, cleaning_log: list[CleaningLogEntry],
                       kpis: dict, ai_text: str, charts_html: list[str]) -> str:
    cleaning_rows = "".join(
        f"<tr><td>{e.column}</td><td>{e.operation}</td><td>{e.rows_affected}</td><td>{e.reason}</td></tr>"
        for e in cleaning_log
    ) or "<tr><td colspan='4'>No cleaning operations were necessary.</td></tr>"

    kpi_html = "".join(f"<div class='kpi'><div class='kpi-val'>{v}</div><div class='kpi-label'>{k}</div></div>"
                        for k, v in kpis.items())

    charts_block = "".join(f"<div class='chart'>{c}</div>" for c in charts_html)

    ai_html = ai_text.replace("\n", "<br>")

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>InsightAI Data Analysis Report</title>
<style>
body {{ font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 40px; color: #1a1a2e; background:#fafafa;}}
h1 {{ color: #4338ca; }}
h2 {{ color: #312e81; border-bottom: 2px solid #e0e7ff; padding-bottom: 6px; margin-top: 36px;}}
.kpis {{ display: flex; flex-wrap: wrap; gap: 16px; margin: 20px 0; }}
.kpi {{ background: white; border-radius: 12px; padding: 16px 22px; box-shadow: 0 1px 4px rgba(0,0,0,.08); min-width: 140px;}}
.kpi-val {{ font-size: 26px; font-weight: 700; color: #4338ca;}}
.kpi-label {{ font-size: 13px; color: #666; margin-top:4px;}}
table {{ border-collapse: collapse; width: 100%; background:white; }}
td, th {{ border: 1px solid #e5e7eb; padding: 8px 12px; font-size: 13px; text-align:left;}}
.chart {{ margin: 20px 0; }}
.ai-block {{ background: white; border-radius: 12px; padding: 20px; line-height:1.6; }}
.footer {{ margin-top: 50px; font-size: 12px; color: #999; }}
</style></head>
<body>
<h1>InsightAI Data Analysis Report</h1>
<p><b>Dataset:</b> {meta.get('name')} &nbsp; | &nbsp; <b>Analysis date:</b> {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>

<h2>Dataset Overview</h2>
<div class="kpis">{kpi_html}</div>

<h2>Data Quality</h2>
<p>Overall data quality score: <b>{quality['score']} / 100</b><br>
Missing rate: {quality['missing_rate_pct']}% &nbsp;|&nbsp; Duplicate rate: {quality['duplicate_rate_pct']}%
&nbsp;|&nbsp; Constant columns: {quality['constant_columns']}</p>

<h2>Cleaning Performed</h2>
<table><tr><th>Column</th><th>Operation</th><th>Rows Affected</th><th>Reason</th></tr>{cleaning_rows}</table>

<h2>Visualizations</h2>
{charts_block}

<h2>AI-Generated Business Insights</h2>
<div class="ai-block">{ai_html}</div>

<h2>Limitations</h2>
<p>This report is generated automatically. Statistical relationships (correlation) do not imply causation.
Forecasts are estimates based on historical patterns and are not guaranteed. AI-generated text is derived
strictly from the computed numbers above but should be reviewed by a human analyst before business decisions
are made.</p>

<div class="footer">Generated by InsightAI — Autonomous AI Data Analyst.</div>
</body></html>"""


# ==============================================================================
# 15. STREAMLIT APP
# ==============================================================================

def kpi_card_row(items: list[tuple[str, Any]]):
    cols = st.columns(len(items))
    for c, (label, value) in zip(cols, items):
        c.metric(label, value)


def safe_run(fn, *args, **kwargs):
    """Run a step, never crash the whole app."""
    try:
        return fn(*args, **kwargs)
    except Exception as e:  # noqa: BLE001
        st.warning(f"⚠️ Step '{fn.__name__}' skipped due to an error: {e}")
        return None


def main():
    st.title(f"📊 {APP_TITLE}")
    st.caption(APP_SUBTITLE)

    with st.sidebar:
        st.header("InsightAI")
        page = st.radio("Navigate", [
            "Upload Dataset", "Dataset Information", "Data Cleaning", "EDA",
            "Composition", "Distribution", "Comparison", "Relationship",
            "Sentiment Analysis", "Time Series", "AI Insights", "RAG Knowledge",
            "Dashboard", "Final Report", "Export", "Settings",
        ])
        st.divider()
        st.subheader("Settings")
        SETTINGS.ollama_url = st.text_input("Ollama URL", SETTINGS.ollama_url)
        SETTINGS.ollama_model = st.text_input("Ollama Model", SETTINGS.ollama_model)
        SETTINGS.temperature = st.slider("Temperature", 0.0, 1.0, SETTINGS.temperature)
        sample_pct = st.selectbox("Sample size (large datasets)", ["Full", "50%", "25%", "10%"], index=0)

    if "df_raw" not in st.session_state:
        st.session_state.df_raw = None
        st.session_state.df_clean = None
        st.session_state.schema = None
        st.session_state.cleaning_log = []
        st.session_state.dataset_name = None
        st.session_state.charts_html = []
        st.session_state.ai_text = ""

    # -------------------------------------------------------------- Upload
    if page == "Upload Dataset":
        st.subheader("Upload your dataset")
        uploaded = st.file_uploader("CSV, XLSX, XLS, TSV, or Parquet", type=["csv", "xlsx", "xls", "tsv", "parquet"])
        if uploaded is not None:
            try:
                df = read_uploaded_file(uploaded)
                if df.empty:
                    st.error("The dataset has no rows.")
                    return
                if sample_pct != "Full":
                    frac = {"50%": 0.5, "25%": 0.25, "10%": 0.1}[sample_pct]
                    df = df.sample(frac=frac, random_state=42)
                st.session_state.df_raw = df
                st.session_state.dataset_name = uploaded.name
                st.session_state.schema = detect_schema(df)
                cleaned, log = clean_dataset(df, st.session_state.schema)
                st.session_state.df_clean = cleaned
                st.session_state.cleaning_log = log
                st.success(f"Dataset detected: **{uploaded.name}** — {len(df):,} records, {len(df.columns)} columns.")
                st.dataframe(df.head(20), use_container_width=True)
            except Exception as e:  # noqa: BLE001
                st.error(f"Could not load file: {e}")
        else:
            st.info("Upload a dataset to begin. Sample industries supported: e-commerce, retail, banking, "
                    "marketing, sales, HR, healthcare, manufacturing, education, logistics, support, and more.")
        return

    if st.session_state.df_clean is None:
        st.warning("Please upload a dataset first (see 'Upload Dataset' in the sidebar).")
        return

    df = st.session_state.df_clean
    schema = st.session_state.schema
    numeric_cols = columns_by_type(schema, "NUMERIC", "CURRENCY", "PERCENTAGE")
    cat_cols = columns_by_type(schema, "CATEGORICAL")
    date_cols = columns_by_type(schema, "DATETIME")
    text_cols = columns_by_type(schema, "TEXT")

    # -------------------------------------------------------- Dataset Info
    if page == "Dataset Information":
        st.subheader("Dataset Information")
        quality = data_quality_score(df)
        kpi_card_row([
            ("Rows", f"{len(df):,}"), ("Columns", len(df.columns)),
            ("Data Quality", f"{quality['score']}/100"),
            ("Missing %", f"{quality['missing_rate_pct']}%"),
        ])
        kpi_card_row([
            ("Numeric cols", len(numeric_cols)), ("Categorical cols", len(cat_cols)),
            ("Date cols", len(date_cols)), ("Text cols", len(text_cols)),
        ])
        st.markdown("### Schema")
        st.dataframe(pd.DataFrame(schema.items(), columns=["column", "detected_type"]), use_container_width=True)
        st.markdown("### Sample rows")
        st.dataframe(df.head(20), use_container_width=True)

    # -------------------------------------------------------------- Cleaning
    elif page == "Data Cleaning":
        st.subheader("Data Cleaning")
        log = st.session_state.cleaning_log
        if log:
            st.dataframe(pd.DataFrame([e.__dict__ for e in log]), use_container_width=True)
        else:
            st.success("No cleaning was necessary — the dataset was already clean.")

        st.markdown("### Outlier Detection (IQR method)")
        summary = safe_run(outlier_summary, df, numeric_cols)
        if summary is not None and not summary.empty:
            st.dataframe(summary, use_container_width=True)
            st.caption("Outliers are flagged, not deleted. Use the Dashboard/Export to inspect and decide.")
        else:
            st.info("No numeric columns available for outlier detection.")

    # -------------------------------------------------------------------- EDA
    elif page == "EDA":
        st.subheader("Exploratory Data Analysis")
        st.markdown("### Univariate — Numeric")
        for col in numeric_cols[:8]:
            stats_d = safe_run(univariate_numeric, df, col)
            if stats_d:
                with st.expander(col):
                    st.json({k: round(v, 3) if isinstance(v, (int, float, np.floating)) else v
                             for k, v in stats_d.items()})
        st.markdown("### Univariate — Categorical")
        for col in cat_cols[:8]:
            with st.expander(col):
                st.dataframe(univariate_categorical(df, col), use_container_width=True)
        st.markdown("### Missing Data")
        miss = missing_data_report(df)
        if not miss.empty:
            st.dataframe(miss, use_container_width=True)
            fig = px.bar(miss, x="column", y="missing_pct", title="Missingness by column")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.success("No missing values remain after cleaning.")

    # ---------------------------------------------------------- Composition
    elif page == "Composition":
        st.subheader("Composition — \"What is this data made of?\"")
        if not cat_cols:
            st.info("No categorical columns detected.")
        else:
            cat = st.selectbox("Category column", cat_cols)
            num = st.selectbox("Value column (optional — count if none)", ["(count)"] + numeric_cols)
            num = None if num == "(count)" else num
            comp = safe_run(composition_analysis, df, cat, num)
            if comp is not None:
                c1, c2 = st.columns(2)
                c1.plotly_chart(px.pie(comp, names="category", values="value", hole=0.45,
                                        title=f"Share of {cat}"), use_container_width=True)
                c2.plotly_chart(px.treemap(comp, path=["category"], values="value",
                                            title=f"{cat} composition"), use_container_width=True)
                st.plotly_chart(px.bar(comp, x="category", y="value", title=f"{cat} — stacked view"),
                                 use_container_width=True)

    # ---------------------------------------------------------- Distribution
    elif page == "Distribution":
        st.subheader("Distribution — \"How are values spread?\"")
        if not numeric_cols:
            st.info("No numeric columns detected.")
        else:
            col = st.selectbox("Numeric column", numeric_cols)
            c1, c2 = st.columns(2)
            c1.plotly_chart(px.histogram(df, x=col, marginal="box", title=f"Distribution of {col}"),
                             use_container_width=True)
            c2.plotly_chart(px.violin(df, y=col, box=True, points="outliers", title=f"Violin — {col}"),
                             use_container_width=True)
            stats_d = univariate_numeric(df, col)
            st.json({k: round(v, 3) for k, v in stats_d.items()})

    # ----------------------------------------------------------- Comparison
    elif page == "Comparison":
        st.subheader("Comparison — \"How do groups differ?\"")
        if not cat_cols or not numeric_cols:
            st.info("Need at least one categorical and one numeric column.")
        else:
            cat = st.selectbox("Group by", cat_cols, key="cmp_cat")
            num = st.selectbox("Metric", numeric_cols, key="cmp_num")
            comp = safe_run(comparison_analysis, df, cat, num)
            if comp is not None:
                st.plotly_chart(px.bar(comp, x=cat, y="sum", title=f"Total {num} by {cat}"),
                                 use_container_width=True)
                st.plotly_chart(px.box(df, x=cat, y=num, title=f"{num} spread by {cat}"),
                                 use_container_width=True)
                st.dataframe(comp, use_container_width=True)

    # --------------------------------------------------------- Relationship
    elif page == "Relationship":
        st.subheader("Relationship — \"How are variables connected?\"")
        if len(numeric_cols) < 2:
            st.info("Need at least two numeric columns.")
        else:
            corr = safe_run(relationship_analysis, df, numeric_cols)
            if corr is not None and not corr.empty:
                st.plotly_chart(px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r",
                                           title="Correlation heatmap"), use_container_width=True)
                strong = strongest_relationships(corr)
                st.markdown("**Strongest relationships:**")
                for a, b, v in strong:
                    st.write(f"- {a} ↔ {b}: r = {v:.2f}")
                if strong:
                    a, b, _ = strong[0]
                    st.plotly_chart(px.scatter(df, x=a, y=b, trendline="ols" if SKLEARN_OK else None,
                                                title=f"{a} vs {b}"), use_container_width=True)

    # -------------------------------------------------------- Sentiment
    elif page == "Sentiment Analysis":
        st.subheader("Sentiment Analysis")
        if not text_cols:
            st.info("No text/review/feedback columns detected in this dataset.")
        elif not VADER_OK:
            st.warning("Install `vaderSentiment` (see requirements.txt) to enable sentiment analysis.")
        else:
            col = st.selectbox("Text column", text_cols)
            sent = safe_run(sentiment_analysis, df, col)
            if sent is not None:
                dist = sent["sentiment"].value_counts(normalize=True).mul(100).round(1)
                kpi_card_row([(k, f"{v}%") for k, v in dist.items()])
                st.plotly_chart(px.pie(names=dist.index, values=dist.values, title="Sentiment distribution"),
                                 use_container_width=True)
                if date_cols:
                    dcol = st.selectbox("Date column (sentiment over time)", date_cols)
                    tmp = df[[dcol]].copy()
                    tmp["sentiment"] = sent["sentiment"].reindex(tmp.index)
                    tmp[dcol] = pd.to_datetime(tmp[dcol], errors="coerce")
                    tmp = tmp.dropna()
                    if not tmp.empty:
                        trend = tmp.groupby([pd.Grouper(key=dcol, freq="ME"), "sentiment"]).size().reset_index(name="count")
                        st.plotly_chart(px.line(trend, x=dcol, y="count", color="sentiment",
                                                 title="Sentiment over time"), use_container_width=True)
                pos_words = frequent_words(sent["text"], sent["sentiment"], "Positive")
                neg_words = frequent_words(sent["text"], sent["sentiment"], "Negative")
                c1, c2 = st.columns(2)
                c1.markdown("**Frequent positive words**")
                c1.write(", ".join(f"{w} ({c})" for w, c in pos_words) or "—")
                c2.markdown("**Frequent negative words**")
                c2.write(", ".join(f"{w} ({c})" for w, c in neg_words) or "—")

    # -------------------------------------------------------- Time Series
    elif page == "Time Series":
        st.subheader("Time-Series Analysis")
        if not date_cols or not numeric_cols:
            st.info("Need at least one date column and one numeric column.")
        else:
            dcol = st.selectbox("Date column", date_cols)
            vcol = st.selectbox("Value column", numeric_cols)
            result = safe_run(time_series_analysis, df, dcol, vcol)
            if result and "error" not in result:
                st.plotly_chart(px.line(result["monthly"], title=f"Monthly {vcol}"), use_container_width=True)
                st.plotly_chart(px.line(result["rolling_7"], title="7-day rolling average"), use_container_width=True)
                if result.get("overall_growth_pct") is not None:
                    st.metric("Overall growth (first vs last period)", f"{result['overall_growth_pct']}%")
                if "forecast" in result:
                    st.markdown("**Forecast (next 3 periods — Exponential Smoothing, historical estimate only):**")
                    st.dataframe(result["forecast"].rename("forecast"), use_container_width=True)
                    st.caption("⚠️ This is a statistical estimate based on past patterns, not a guarantee.")
                if "decomposition" in result:
                    dec = result["decomposition"]
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(y=dec.trend, name="Trend"))
                    fig.add_trace(go.Scatter(y=dec.seasonal, name="Seasonal"))
                    fig.add_trace(go.Scatter(y=dec.resid, name="Residual"))
                    fig.update_layout(title="Seasonal decomposition")
                    st.plotly_chart(fig, use_container_width=True)
            elif result:
                st.warning(result["error"])

    # -------------------------------------------------------- AI Insights
    elif page == "AI Insights":
        st.subheader("AI-Powered Business Insights")
        running = ollama_is_running(SETTINGS.ollama_url)
        if not running:
            st.error("Ollama is not running. Start Ollama and try again. "
                      "(Deterministic EDA above still works fully without it.)")
        if st.button("Generate AI Insights", disabled=not running):
            with st.spinner("Analyzing with Ollama..."):
                quality = data_quality_score(df)
                structured = {
                    "rows": len(df), "columns": len(df.columns),
                    "data_quality_score": quality,
                    "numeric_summary": {c: safe_run(univariate_numeric, df, c) for c in numeric_cols[:6]},
                    "top_correlations": [
                        {"a": a, "b": b, "r": round(v, 2)}
                        for a, b, v in strongest_relationships(relationship_analysis(df, numeric_cols))
                    ] if len(numeric_cols) >= 2 else [],
                    "missing_data": missing_data_report(df).to_dict("records"),
                }
                rag_ctx = rag_retrieve("business insights EDA data quality trends risks")
                prompt = build_insight_prompt(structured, rag_ctx)
                ai_text = ollama_generate(prompt, SETTINGS.ollama_url, SETTINGS.ollama_model,
                                           SETTINGS.temperature, SETTINGS.max_tokens)
                st.session_state.ai_text = ai_text
        if st.session_state.ai_text:
            st.markdown(st.session_state.ai_text)

    # -------------------------------------------------------- RAG Knowledge
    elif page == "RAG Knowledge":
        st.subheader("RAG Knowledge Base")
        st.caption("Analytical methodology documents used to ground AI explanations.")
        query = st.text_input("Search the knowledge base", "correlation and outliers")
        if query:
            for snippet in rag_retrieve(query, top_k=4):
                st.info(snippet)
        st.caption(f"Embeddings backend: {'sentence-transformers' if SBERT_OK else 'keyword fallback (install sentence-transformers for semantic search)'}")

    # -------------------------------------------------------------- Dashboard
    elif page == "Dashboard":
        st.subheader("Executive Dashboard")
        quality = data_quality_score(df)
        kpi_card_row([
            ("Total Records", f"{len(df):,}"), ("Total Columns", len(df.columns)),
            ("Data Quality Score", f"{quality['score']}/100"), ("Missing Values", f"{quality['missing_rate_pct']}%"),
        ])
        kpi_card_row([
            ("Duplicate Rows", f"{quality['duplicate_rate_pct']}%"), ("Numeric Cols", len(numeric_cols)),
            ("Categorical Cols", len(cat_cols)), ("Date Cols", len(date_cols)),
        ])
        tabs = st.tabs(["Composition", "Distribution", "Comparison", "Relationships", "Anomalies"])
        with tabs[0]:
            if cat_cols:
                comp = composition_analysis(df, cat_cols[0], numeric_cols[0] if numeric_cols else None)
                st.plotly_chart(px.pie(comp, names="category", values="value", hole=0.4), use_container_width=True)
        with tabs[1]:
            if numeric_cols:
                st.plotly_chart(px.histogram(df, x=numeric_cols[0]), use_container_width=True)
        with tabs[2]:
            if cat_cols and numeric_cols:
                comp = comparison_analysis(df, cat_cols[0], numeric_cols[0])
                st.plotly_chart(px.bar(comp, x=cat_cols[0], y="sum"), use_container_width=True)
        with tabs[3]:
            if len(numeric_cols) >= 2:
                st.plotly_chart(px.imshow(relationship_analysis(df, numeric_cols), text_auto=".2f"),
                                 use_container_width=True)
        with tabs[4]:
            anomalies = anomaly_detection(df, numeric_cols)
            st.dataframe(anomalies, use_container_width=True) if not anomalies.empty else st.success("No significant anomalies detected.")

    # -------------------------------------------------------------- Report
    elif page == "Final Report":
        st.subheader("Final Executive Report")
        quality = data_quality_score(df)
        kpis = {
            "Records": f"{len(df):,}", "Columns": len(df.columns),
            "Quality Score": f"{quality['score']}/100", "Missing %": f"{quality['missing_rate_pct']}%",
            "Duplicate %": f"{quality['duplicate_rate_pct']}%",
        }
        charts_html = []
        if numeric_cols:
            charts_html.append(px.histogram(df, x=numeric_cols[0]).to_html(full_html=False, include_plotlyjs="cdn"))
        if cat_cols:
            comp = composition_analysis(df, cat_cols[0], numeric_cols[0] if numeric_cols else None)
            charts_html.append(px.pie(comp, names="category", values="value").to_html(full_html=False, include_plotlyjs=False))
        if len(numeric_cols) >= 2:
            charts_html.append(px.imshow(relationship_analysis(df, numeric_cols), text_auto=".2f")
                                .to_html(full_html=False, include_plotlyjs=False))

        ai_text = st.session_state.ai_text or "(Run 'AI Insights' first to include AI-generated commentary here.)"
        html = build_html_report(
            {"name": st.session_state.dataset_name}, quality, st.session_state.cleaning_log,
            kpis, ai_text, charts_html,
        )
        st.components.v1.html(html, height=600, scrolling=True)
        st.download_button("Download HTML Report", html, file_name="insightai_report.html", mime="text/html")

    # -------------------------------------------------------------- Export
    elif page == "Export":
        st.subheader("Export Results")
        st.download_button("Download Cleaned CSV", df.to_csv(index=False), "cleaned_dataset.csv", "text/csv")
        json_payload = {
            "dataset": st.session_state.dataset_name,
            "rows": len(df), "columns": len(df.columns),
            "schema": schema, "data_quality": data_quality_score(df),
            "cleaning_log": [e.__dict__ for e in st.session_state.cleaning_log],
        }
        st.download_button("Download Analysis JSON", json.dumps(json_payload, indent=2, default=str),
                            "analysis_results.json", "application/json")
        summary_txt = f"InsightAI Summary\nDataset: {st.session_state.dataset_name}\nRows: {len(df)}\n" \
                      f"Columns: {len(df.columns)}\nQuality Score: {data_quality_score(df)['score']}/100\n"
        st.download_button("Download Summary (TXT)", summary_txt, "summary.txt", "text/plain")

    # -------------------------------------------------------------- Settings
    elif page == "Settings":
        st.subheader("Settings")
        st.write("Ollama URL:", SETTINGS.ollama_url)
        st.write("Ollama Model:", SETTINGS.ollama_model)
        st.write("Ollama reachable:", ollama_is_running(SETTINGS.ollama_url))
        st.write("sentence-transformers available:", SBERT_OK)
        st.write("chromadb available:", CHROMA_OK)
        st.write("statsmodels available:", STATSMODELS_OK)
        st.write("scikit-learn available:", SKLEARN_OK)
        st.write("vaderSentiment available:", VADER_OK)


if __name__ == "__main__":
    main()
